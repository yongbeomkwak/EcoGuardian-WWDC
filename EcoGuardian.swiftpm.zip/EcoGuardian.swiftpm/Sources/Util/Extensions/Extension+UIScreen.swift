//
//  File.swift
//
//
//  Created by yongbeomkwak on 2023/04/03.
//
import Foundation
import UIKit

extension UIScreen {
    
    static let width = UIScreen.main.bounds.width
    static let height = UIScreen.main.bounds.height

    
}
